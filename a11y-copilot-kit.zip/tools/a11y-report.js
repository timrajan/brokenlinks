#!/usr/bin/env node
/**
 * a11y-report.js
 * Builds a single self-contained HTML accessibility report from findings.json
 * (written by the Copilot "a11y-test" prompt). Screenshots are embedded as base64,
 * so the HTML file can be emailed or attached on its own.
 *
 * Usage: node tools/a11y-report.js a11y-results/findings.json a11y-results/accessibility-report.html
 * No dependencies. Node 16+.
 */
const fs = require('fs');
const path = require('path');

const [, , inFile = 'a11y-results/findings.json', outFile = 'a11y-results/accessibility-report.html'] = process.argv;
const baseDir = path.dirname(path.resolve(inFile));
const data = JSON.parse(fs.readFileSync(inFile, 'utf8'));
const session = data.session || {};
const pages = data.pages || [];

const IMPACTS = ['critical', 'serious', 'moderate', 'minor'];
const when = d => { const t = new Date(d); return isNaN(t) ? String(d || '') : t.toLocaleString(); };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function img(rel) {
  if (!rel) return null;
  const candidates = [path.resolve(baseDir, rel), path.resolve(baseDir, 'screenshots', path.basename(rel)), path.resolve(rel)];
  const file = candidates.find(f => fs.existsSync(f));
  if (!file) return null;
  const ext = path.extname(file).slice(1).toLowerCase();
  const mime = ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' : 'image/png';
  return `data:${mime};base64,${fs.readFileSync(file).toString('base64')}`;
}

const count = (issues, imp) => issues.filter(i => (i.impact || 'minor').toLowerCase() === imp).length;
const totals = Object.fromEntries(IMPACTS.map(imp => [imp, pages.reduce((n, p) => n + count(p.issues || [], imp), 0)]));
const totalIssues = IMPACTS.reduce((n, k) => n + totals[k], 0);
const totalReview = pages.reduce((n, p) => n + (p.needsReview || []).length, 0);

// most common WCAG criteria
const wcagFreq = {};
pages.forEach(p => (p.issues || []).forEach(i => String(i.wcag || 'n/a').split(',').map(s => s.trim()).filter(Boolean)
  .forEach(c => { wcagFreq[c] = (wcagFreq[c] || 0) + 1; })));
const topWcag = Object.entries(wcagFreq).sort((a, b) => b[1] - a[1]).slice(0, 5);

const pageRows = pages.map(p => {
  const is = p.issues || [];
  return `<tr><td><a href="#${esc(p.id)}">${esc(p.id)}</a></td><td>${esc(p.title || '')}</td><td class="url">${esc(p.url)}</td>
  ${IMPACTS.map(imp => `<td class="num ${count(is, imp) ? imp : ''}">${count(is, imp)}</td>`).join('')}
  <td class="num">${(p.needsReview || []).length}</td></tr>`;
}).join('');

const pageSections = pages.map(p => {
  const issues = (p.issues || []).slice().sort((a, b) => IMPACTS.indexOf((a.impact || 'minor').toLowerCase()) - IMPACTS.indexOf((b.impact || 'minor').toLowerCase()));
  const shot = img(p.pageScreenshot);
  const rows = issues.map(i => {
    const imp = (i.impact || 'minor').toLowerCase();
    const s = img(i.screenshot);
    return `<tr class="issue" data-impact="${imp}">
      <td class="num">${esc(i.no)}</td>
      <td><strong>${esc(i.element)}</strong>${i.selector ? `<div class="sel"><code>${esc(i.selector)}</code></div>` : ''}${i.html ? `<details><summary>HTML</summary><pre>${esc(i.html)}</pre></details>` : ''}</td>
      <td class="shot">${s ? `<img src="${s}" alt="Screenshot of ${esc(i.element)}" loading="lazy" onclick="zoom(this)">` : '<span class="muted">—</span>'}</td>
      <td>${esc(i.problem)}</td>
      <td><span class="wcag">${esc(i.wcag || '')}</span>${i.wcagName ? `<div class="muted small">${esc(i.wcagName)}</div>` : ''}${i.level ? `<div class="muted small">Level ${esc(i.level)}</div>` : ''}</td>
      <td><span class="badge ${imp}">${imp}</span>${i.source ? `<div class="muted small">${esc(i.source)}</div>` : ''}</td>
      <td>${esc(i.fix)}${i.helpUrl ? `<div><a href="${esc(i.helpUrl)}" target="_blank" rel="noopener">Learn more ↗</a></div>` : ''}</td>
    </tr>`;
  }).join('');
  const review = (p.needsReview || []).map(r => `<li><strong>${esc(r.element)}</strong> — ${esc(r.problem)} ${r.wcag ? `<span class="wcag">${esc(r.wcag)}</span>` : ''}</li>`).join('');
  const passed = (p.passedHighlights || []).map(x => `<li>${esc(x)}</li>`).join('');
  return `<section class="page" id="${esc(p.id)}">
    <details open>
      <summary><span class="pid">${esc(p.id)}</span> ${esc(p.title || p.url)}
        <span class="chips">${IMPACTS.map(imp => count(issues, imp) ? `<span class="badge ${imp}">${count(issues, imp)} ${imp}</span>` : '').join('')}</span></summary>
      <div class="meta"><a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.url)}</a> · tested ${esc(when(p.testedAt))}
        ${p.keyboardStops != null ? ` · ${esc(p.keyboardStops)} keyboard stops` : ''}
        ${p.axeAvailable === false ? ' · <span class="warn">axe-core blocked on this page — keyboard and structure checks only</span>' : ''}</div>
      ${shot ? `<img class="pageshot" src="${shot}" alt="Screenshot of ${esc(p.title || p.url)}" onclick="zoom(this)">` : ''}
      ${issues.length ? `<table class="issues"><thead><tr><th>#</th><th>Element</th><th>Snippet</th><th>Why it's not accessible</th><th>WCAG</th><th>Impact</th><th>How to fix</th></tr></thead><tbody>${rows}</tbody></table>`
        : '<p class="ok">No accessibility issues found by the automated and keyboard checks.</p>'}
      ${review ? `<h4>🔍 Needs manual review</h4><ul class="review">${review}</ul>` : ''}
      ${passed ? `<h4>✅ Passed highlights</h4><ul class="passed">${passed}</ul>` : ''}
    </details>
  </section>`;
}).join('');

const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Accessibility Report — ${esc(session.startUrl || '')}</title>
<style>
:root{--bg:#f6f7f9;--card:#fff;--ink:#1b1f24;--muted:#5b6470;--line:#e2e5ea;--critical:#b42318;--serious:#c4320a;--moderate:#a15c07;--minor:#475467;--accent:#1d4ed8}
*{box-sizing:border-box}body{margin:0;font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--ink)}
header{background:#111827;color:#fff;padding:28px 32px}header h1{margin:0 0 6px;font-size:24px}header .sub{color:#c7cdd6}
main{max-width:1400px;margin:0 auto;padding:24px 32px 60px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}.card .n{font-size:28px;font-weight:700}.card .l{color:var(--muted);text-transform:capitalize}
.card.critical .n{color:var(--critical)}.card.serious .n{color:var(--serious)}.card.moderate .n{color:var(--moderate)}.card.minor .n{color:var(--minor)}
.panel{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px 18px;margin-bottom:20px}
.panel h2{margin:0 0 10px;font-size:16px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{background:#f0f2f5;font-weight:600;position:sticky;top:0}td.num,th.num{text-align:center}td.url{color:var(--muted);word-break:break-all}
td.critical{color:var(--critical);font-weight:700}td.serious{color:var(--serious);font-weight:700}td.moderate{color:var(--moderate);font-weight:700}td.minor{color:var(--minor);font-weight:700}
.toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:0 0 16px}
.toolbar button{border:1px solid var(--line);background:#fff;border-radius:999px;padding:6px 14px;cursor:pointer;font:inherit;text-transform:capitalize}
.toolbar button[aria-pressed=true]{background:#111827;color:#fff;border-color:#111827}
.toolbar input{flex:1;min-width:220px;padding:7px 12px;border:1px solid var(--line);border-radius:8px;font:inherit}
.page{background:var(--card);border:1px solid var(--line);border-radius:10px;margin-bottom:16px;overflow:hidden}
.page > details > summary{padding:14px 18px;font-size:16px;font-weight:600;cursor:pointer;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.pid{background:#111827;color:#fff;border-radius:6px;padding:2px 8px;font-size:13px}.chips{display:flex;gap:6px;margin-left:auto}
.page .meta{padding:0 18px 10px;color:var(--muted)}.page > details > :not(summary){margin-left:18px;margin-right:18px}
.pageshot{max-width:420px;border:1px solid var(--line);border-radius:6px;cursor:zoom-in;margin-bottom:12px}
table.issues{margin-bottom:16px;width:calc(100% - 36px)}
.shot img{max-width:220px;max-height:120px;border:2px solid var(--line);border-radius:4px;cursor:zoom-in;background:#fff}
.badge{display:inline-block;border-radius:999px;padding:2px 9px;font-size:12px;font-weight:600;color:#fff;text-transform:capitalize}
.badge.critical{background:var(--critical)}.badge.serious{background:var(--serious)}.badge.moderate{background:var(--moderate)}.badge.minor{background:var(--minor)}
.wcag{font-family:ui-monospace,monospace;background:#eef2ff;color:#3730a3;border-radius:4px;padding:1px 6px;font-size:12px}
.sel code{font-size:12px;color:var(--muted);word-break:break-all}pre{white-space:pre-wrap;word-break:break-all;background:#f6f8fa;padding:8px;border-radius:6px;font-size:12px}
.muted{color:var(--muted)}.small{font-size:12px}.warn{color:var(--serious);font-weight:600}.ok{color:#067647;font-weight:600}
.review li,.passed li{margin-bottom:4px}h4{margin:14px 0 6px}
a{color:var(--accent)}a:focus,button:focus,summary:focus,input:focus{outline:3px solid #f59e0b;outline-offset:2px}
#lightbox{position:fixed;inset:0;background:rgba(0,0,0,.8);display:none;align-items:center;justify-content:center;z-index:9;cursor:zoom-out}
#lightbox img{max-width:92vw;max-height:92vh;background:#fff;border-radius:6px}
.note{color:var(--muted);font-size:13px}
@media print{.toolbar,#lightbox{display:none}.page details{display:block}header{background:#fff;color:#000}}
</style></head><body>
<header><h1>Accessibility Test Report</h1>
<div class="sub">${esc(session.startUrl || '')} · Standard: ${esc(session.standard || 'WCAG 2.2 AA')} · ${pages.length} page(s) tested · ${esc(when(session.finishedAt || session.startedAt || new Date()))}</div></header>
<main>
<div class="cards">
  <div class="card"><div class="n">${totalIssues}</div><div class="l">Total issues</div></div>
  ${IMPACTS.map(k => `<div class="card ${k}"><div class="n">${totals[k]}</div><div class="l">${k}</div></div>`).join('')}
  <div class="card"><div class="n">${totalReview}</div><div class="l">Needs review</div></div>
</div>
<div class="panel"><h2>Pages tested</h2>
<table><thead><tr><th>ID</th><th>Title</th><th>URL</th>${IMPACTS.map(k => `<th class="num" style="text-transform:capitalize">${k}</th>`).join('')}<th class="num">Review</th></tr></thead><tbody>${pageRows}</tbody></table></div>
${topWcag.length ? `<div class="panel"><h2>Most frequent WCAG failures</h2>${topWcag.map(([c, n]) => `<span class="wcag">${esc(c)}</span> × ${n}`).join(' &nbsp; ')}</div>` : ''}
<div class="toolbar" role="toolbar" aria-label="Filter issues">
  <button aria-pressed="true" data-f="all">All</button>${IMPACTS.map(k => `<button aria-pressed="false" data-f="${k}">${k}</button>`).join('')}
  <input type="search" id="q" placeholder="Search element, problem, WCAG…" aria-label="Search issues">
  <button id="toggle" aria-pressed="false">Collapse all</button>
</div>
${pageSections || '<p>No pages were tested.</p>'}
<p class="note">Limitations: this report combines automated axe-core scanning, a keyboard (Tab) pass and an accessibility-tree review. These find most WCAG issues, but not all. The quality of alt text, caption accuracy, reading order in complex widgets and real screen-reader announcements should still get a short manual check. Items under "Needs manual review" list where to start.</p>
</main>
<div id="lightbox" onclick="this.style.display='none'"><img alt=""></div>
<script>
function zoom(el){const lb=document.getElementById('lightbox');lb.querySelector('img').src=el.src;lb.querySelector('img').alt=el.alt;lb.style.display='flex';}
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.getElementById('lightbox').style.display='none';});
let filter='all';const q=document.getElementById('q');
function apply(){const t=q.value.toLowerCase();document.querySelectorAll('tr.issue').forEach(r=>{const okF=filter==='all'||r.dataset.impact===filter;const okQ=!t||r.textContent.toLowerCase().includes(t);r.style.display=okF&&okQ?'':'none';});}
document.querySelectorAll('[data-f]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.f;document.querySelectorAll('[data-f]').forEach(x=>x.setAttribute('aria-pressed',x===b));apply();}));
q.addEventListener('input',apply);
document.getElementById('toggle').addEventListener('click',e=>{const b=e.currentTarget;const collapse=b.getAttribute('aria-pressed')!=='true';document.querySelectorAll('.page details').forEach(d=>d.open=!collapse);b.setAttribute('aria-pressed',collapse);b.textContent=collapse?'Expand all':'Collapse all';});
</script></body></html>`;

fs.mkdirSync(path.dirname(path.resolve(outFile)), { recursive: true });
fs.writeFileSync(outFile, html);
console.log(`Report written: ${outFile}  (${pages.length} pages, ${totalIssues} issues, ${totalReview} to review)`);
