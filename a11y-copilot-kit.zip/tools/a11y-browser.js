#!/usr/bin/env node
/**
 * a11y-browser.js — opens a browser for the accessibility session and KEEPS IT OPEN.
 * You click around in it yourself; a11y-scan.js attaches to it to test the current page.
 *
 * Usage:
 *   node tools/a11y-browser.js <startUrl> [--browser chrome|msedge|chromium] [--port 9222] [--new]
 *
 *   --browser  chrome (default), msedge, or chromium (Playwright's bundled browser)
 *   --port     remote-debugging port the scanner connects to (default 9222)
 *   --new      start a fresh findings.json (otherwise results are appended)
 *
 * Login sessions are kept in a11y-results/.browser-profile, so you usually only log in once.
 * Leave this terminal running. Close the browser window (or Ctrl+C) to end it.
 */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const args = process.argv.slice(2);
const opt = (name, def) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : def; };
let startUrl = args.find(a => !a.startsWith('--') && !['chrome', 'msedge', 'chromium'].includes(a) && !/^\d+$/.test(a));
if (!startUrl) { console.error('Usage: node tools/a11y-browser.js <startUrl> [--browser chrome|msedge|chromium] [--port 9222] [--new]'); process.exit(1); }
if (!/^https?:\/\//i.test(startUrl)) startUrl = 'https://' + startUrl;

const browserName = opt('browser', 'chrome');
const port = Number(opt('port', 9222));
const outDir = path.resolve('a11y-results');
const findingsFile = path.join(outDir, 'findings.json');
fs.mkdirSync(path.join(outDir, 'screenshots'), { recursive: true });

if (args.includes('--new') || !fs.existsSync(findingsFile)) {
  fs.writeFileSync(findingsFile, JSON.stringify({
    session: { startUrl, startedAt: new Date().toISOString(), standard: 'WCAG 2.2 AA' }, pages: []
  }, null, 2));
}
fs.writeFileSync(path.join(outDir, '.session.json'), JSON.stringify({ port, startUrl, browser: browserName }, null, 2));

(async () => {
  const launchOpts = {
    headless: process.env.A11Y_HEADLESS === '1',
    viewport: null,
    args: [`--remote-debugging-port=${port}`, '--start-maximized'],
  };
  if (browserName !== 'chromium') launchOpts.channel = browserName;
  if (process.env.A11Y_BROWSER_PATH) { delete launchOpts.channel; launchOpts.executablePath = process.env.A11Y_BROWSER_PATH; }

  let context;
  try {
    context = await chromium.launchPersistentContext(path.join(outDir, '.browser-profile'), launchOpts);
  } catch (e) {
    console.error(`Could not launch ${browserName}: ${e.message.split('\n')[0]}`);
    console.error('Try --browser msedge, --browser chromium, or set A11Y_BROWSER_PATH to the browser .exe');
    process.exit(1);
  }
  const page = context.pages()[0] || await context.newPage();
  try { await page.goto(startUrl, { waitUntil: 'domcontentloaded', timeout: 60000 }); }
  catch (e) { console.error(`Opened browser, but loading ${startUrl} failed: ${e.message.split('\n')[0]}`); }

  console.log(`A11Y-BROWSER READY on port ${port} — ${startUrl}`);
  console.log('Navigate in the browser window, then run: node tools/a11y-scan.js');
  context.on('close', () => { console.log('Browser closed. Session ended.'); process.exit(0); });
  process.on('SIGINT', async () => { await context.close().catch(() => {}); process.exit(0); });
})();
