#!/usr/bin/env node
/**
 * a11y-scan.js — tests the page currently open in the a11y-browser.js window.
 *
 * Usage:  node tools/a11y-scan.js [--quick] [--replace] [--max-tabs 40]
 *   --quick     axe scan + structure checks only (skip the keyboard Tab pass)
 *   --replace   re-test a page that was already tested (replaces its results)
 *
 * Checks:
 *   A. axe-core (WCAG 2.0/2.1/2.2 A + AA + best practice), loaded from node_modules so
 *      corporate CSP / CDN blocks don't matter
 *   B. Keyboard pass — Tab through the page like a JAWS/NVDA user: focus visibility,
 *      focus traps, unnamed controls, skip link, focus order, mouse-only controls
 *   C. Structure — vague link text, placeholder-only labels
 *   D. Element screenshots for each issue (red outline drawn around the element)
 * Results are appended to a11y-results/findings.json.
 * Exit codes: 0 ok, 2 browser not running, 3 page already tested (use --replace).
 */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const args = process.argv.slice(2);
const QUICK = args.includes('--quick');
const REPLACE = args.includes('--replace');
const MAX_TABS = Number((args[args.indexOf('--max-tabs') + 1]) || 40) || 40;

const outDir = path.resolve('a11y-results');
const shotDir = path.join(outDir, 'screenshots');
const findingsFile = path.join(outDir, 'findings.json');
const sessionFile = path.join(outDir, '.session.json');
fs.mkdirSync(shotDir, { recursive: true });

const SC = {
  '1.1.1': 'Non-text Content', '1.2.2': 'Captions (Prerecorded)', '1.3.1': 'Info and Relationships', '1.3.2': 'Meaningful Sequence',
  '1.3.5': 'Identify Input Purpose', '1.4.1': 'Use of Color', '1.4.3': 'Contrast (Minimum)', '1.4.4': 'Resize Text', '1.4.10': 'Reflow',
  '1.4.11': 'Non-text Contrast', '1.4.12': 'Text Spacing', '2.1.1': 'Keyboard', '2.1.2': 'No Keyboard Trap', '2.2.1': 'Timing Adjustable',
  '2.2.2': 'Pause, Stop, Hide', '2.4.1': 'Bypass Blocks', '2.4.2': 'Page Titled', '2.4.3': 'Focus Order', '2.4.4': 'Link Purpose (In Context)',
  '2.4.6': 'Headings and Labels', '2.4.7': 'Focus Visible', '2.4.11': 'Focus Not Obscured (Minimum)', '2.5.3': 'Label in Name',
  '2.5.8': 'Target Size (Minimum)', '3.1.1': 'Language of Page', '3.1.2': 'Language of Parts', '3.2.2': 'On Input', '3.3.1': 'Error Identification',
  '3.3.2': 'Labels or Instructions', '4.1.1': 'Parsing', '4.1.2': 'Name, Role, Value', '4.1.3': 'Status Messages',
};
const IMPACT_ORDER = ['critical', 'serious', 'moderate', 'minor'];

function wcagFromTags(tags) {
  const scs = tags.map(t => t.match(/^wcag(\d)(\d)(\d+)$/)).filter(Boolean).map(m => `${m[1]}.${m[2]}.${m[3]}`);
  const level = tags.some(t => /^wcag2\d?aa$/.test(t)) ? 'AA' : tags.some(t => /^wcag2\d?a$/.test(t)) ? 'A'
    : tags.includes('best-practice') ? 'Best practice' : '';
  return { wcag: scs.join(', ') || (level === 'Best practice' ? 'Best practice' : ''), wcagName: scs.map(s => SC[s]).filter(Boolean).join('; '), level };
}

// Runs in the page: a plain-English description of an element ("Email" text field in form)
const DESCRIBE_FN = `
window.__a11yDescribe = function (el) {
  if (!el) return 'Unknown element';
  const tag = el.tagName.toLowerCase();
  if (tag === 'html' || tag === 'body') return 'Whole page';
  const role = el.getAttribute('role');
  const type = (el.getAttribute('type') || '').toLowerCase();
  const kinds = { a: 'link', button: 'button', select: 'dropdown', textarea: 'text area', img: 'image', svg: 'icon', iframe: 'frame',
    table: 'table', nav: 'navigation', form: 'form', video: 'video', ul: 'list', ol: 'list', li: 'list item', label: 'label', p: 'text', span: 'text', div: 'container' };
  let kind = role || kinds[tag] || tag;
  if (tag === 'input') kind = ({ checkbox: 'checkbox', radio: 'radio button', submit: 'submit button', button: 'button', image: 'image button',
    search: 'search field', email: 'email field', password: 'password field', file: 'file upload', range: 'slider', date: 'date field' })[type] || 'text field';
  if (/^h[1-6]$/.test(tag)) kind = 'heading ' + tag[1];
  const by = (el.getAttribute('aria-labelledby') || '').split(/\\s+/).map(id => document.getElementById(id)?.innerText || '').join(' ').trim();
  let name = el.getAttribute('aria-label') || by || (el.labels && el.labels[0] && el.labels[0].innerText) || el.getAttribute('alt')
    || el.getAttribute('title') || el.getAttribute('placeholder') || (el.innerText || '').trim() || el.value || el.getAttribute('name') || el.id || '';
  name = String(name).replace(/\\s+/g, ' ').trim().slice(0, 45);
  const region = el.closest('header,[role=banner]') ? ' in header' : el.closest('nav,[role=navigation]') ? ' in navigation'
    : el.closest('footer,[role=contentinfo]') ? ' in footer' : el.closest('form') ? ' in form' : el.closest('dialog,[role=dialog]') ? ' in dialog' : '';
  const label = name ? '"' + name + '" ' + kind : kind.charAt(0).toUpperCase() + kind.slice(1) + ' (no name)';
  return label + region;
};
window.__a11yName = function (el) {
  const by = (el.getAttribute('aria-labelledby') || '').split(/\\s+/).map(id => document.getElementById(id)?.innerText || '').join(' ').trim();
  return (el.getAttribute('aria-label') || by || (el.labels && el.labels[0] && el.labels[0].innerText) || el.getAttribute('alt')
    || el.getAttribute('title') || el.getAttribute('placeholder') || (el.innerText || '').trim() || (['submit','button','reset'].includes(el.type) ? el.value : '')
    || el.querySelector?.('img[alt]')?.getAttribute('alt') || el.querySelector?.('svg title')?.textContent || '').trim();
};`;

async function pickCurrentPage(browser) {
  const pages = browser.contexts().flatMap(c => c.pages()).filter(p => !p.url().startsWith('devtools://') && p.url() !== 'about:blank');
  if (!pages.length) return null;
  for (const p of pages) {
    try { if (await p.evaluate(() => document.visibilityState === 'visible' && document.hasFocus())) return p; } catch { /* ignore */ }
  }
  for (const p of pages) {
    try { if (await p.evaluate(() => document.visibilityState === 'visible')) return p; } catch { /* ignore */ }
  }
  return pages[pages.length - 1];
}

async function elementShot(page, selector, file) {
  try {
    const loc = page.locator(selector).first();
    if (!(await loc.count()) || !(await loc.isVisible())) return null;
    await loc.scrollIntoViewIfNeeded({ timeout: 3000 });
    const box = await loc.boundingBox();
    const vp = await page.evaluate(() => ({ w: innerWidth, h: innerHeight }));
    if (!box || box.width < 2 || box.height < 2 || box.width * box.height > vp.w * vp.h * 0.5) return null;
    const handle = await loc.elementHandle();
    const prev = await handle.evaluate(el => { const o = el.style.outline, off = el.style.outlineOffset; el.style.outline = '3px solid #e11d48'; el.style.outlineOffset = '2px'; return [o, off]; });
    const pad = 12;
    const clip = { x: Math.max(0, box.x - pad), y: Math.max(0, box.y - pad) };
    clip.width = Math.min(vp.w - clip.x, box.width + pad * 2);
    clip.height = Math.min(vp.h - clip.y, box.height + pad * 2);
    if (clip.width < 2 || clip.height < 2) return null;
    await page.screenshot({ path: path.join(shotDir, file), clip });
    await handle.evaluate((el, [o, off]) => { el.style.outline = o; el.style.outlineOffset = off; }, prev);
    return `screenshots/${file}`;
  } catch { return null; }
}

(async () => {
  const session = fs.existsSync(sessionFile) ? JSON.parse(fs.readFileSync(sessionFile, 'utf8')) : { port: 9222 };
  let browser;
  try { browser = await chromium.connectOverCDP(`http://127.0.0.1:${session.port}`, { timeout: 8000 }); }
  catch { console.error(`NO_BROWSER: no a11y browser on port ${session.port}. Start it with: node tools/a11y-browser.js <url>`); process.exit(2); }

  const page = await pickCurrentPage(browser);
  if (!page) { console.error('NO_PAGE: no open page found in the browser.'); process.exit(2); }
  await page.bringToFront().catch(() => {});
  await page.waitForLoadState('domcontentloaded').catch(() => {});

  const findings = fs.existsSync(findingsFile) ? JSON.parse(fs.readFileSync(findingsFile, 'utf8'))
    : { session: { startUrl: page.url(), startedAt: new Date().toISOString(), standard: 'WCAG 2.2 AA' }, pages: [] };
  const url = page.url();
  const existing = findings.pages.findIndex(p => p.url === url);
  if (existing >= 0 && !REPLACE) {
    console.log(`ALREADY_TESTED: ${url} was tested as ${findings.pages[existing].id}. Re-run with --replace to test it again.`);
    await browser.close(); process.exit(3);
  }
  const pageId = existing >= 0 ? findings.pages[existing].id : `P${findings.pages.length + 1}`;
  for (const f of fs.readdirSync(shotDir)) if (f.startsWith(pageId + '-')) fs.unlinkSync(path.join(shotDir, f));

  await page.evaluate(DESCRIBE_FN);
  await page.evaluate(() => window.scrollTo(0, 0));
  const title = await page.title();
  const pageScreenshot = `screenshots/${pageId}-page.png`;
  await page.screenshot({ path: path.join(outDir, pageScreenshot) }).catch(() => {});

  const issues = [];
  const needsReview = [];
  const passedHighlights = [];
  let shotCount = 0;
  const shot = async (selector) => (shotCount < 25 && selector) ? (async () => {
    const r = await elementShot(page, selector, `${pageId}-${String(issues.length + 1).padStart(2, '0')}.png`);
    if (r) shotCount++; return r;
  })() : null;

  // ---------- A. axe-core ----------
  let axeAvailable = true;
  try {
    const axeSource = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
    await page.evaluate(axeSource);
    const res = await page.evaluate(async () => {
      const r = await window.axe.run(document, {
        runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] },
        resultTypes: ['violations', 'incomplete'],
      });
      const slim = v => ({ id: v.id, impact: v.impact, help: v.help, description: v.description, helpUrl: v.helpUrl, tags: v.tags,
        nodes: v.nodes.map(n => {
          const sel = n.target.length === 1 && typeof n.target[0] === 'string' ? n.target[0] : null;
          let el = null; try { el = sel && document.querySelector(sel); } catch { /* ignore */ }
          if (el) el.setAttribute('data-a11y-axe', ((el.getAttribute('data-a11y-axe') || '') + ' ' + v.id).trim());
          return { selector: sel, html: n.html.slice(0, 300), summary: n.failureSummary || '', name: el ? window.__a11yDescribe(el) : null };
        }) });
      return { violations: r.violations.map(slim), incomplete: r.incomplete.map(slim), passes: r.passes.map(p => p.help) };
    });
    res.violations.sort((a, b) => IMPACT_ORDER.indexOf(a.impact) - IMPACT_ORDER.indexOf(b.impact));
    for (const v of res.violations) {
      const w = wcagFromTags(v.tags);
      const base = { wcag: w.wcag, wcagName: w.wcagName, level: w.level, impact: v.impact || 'minor', source: 'axe', helpUrl: v.helpUrl };
      const clean = s => s.split('\n').map(l => l.trim()).filter(l => l && !/^Fix (any|all) of the following:?$/i.test(l)).map(l => l.replace(/\.$/, '')).join('; ') + '.';
      if (v.nodes.length <= 3) {
        for (const n of v.nodes) {
          issues.push({ no: issues.length + 1, element: n.name || v.help, selector: n.selector, html: n.html,
            problem: `${v.help}. ${clean(n.summary)}`, fix: `${v.description}. See "Learn more" for the fix pattern.`, ...base,
            screenshot: await shot(n.selector) });
        }
      } else {
        const n = v.nodes[0];
        issues.push({ no: issues.length + 1, element: `${v.nodes.length} elements — e.g. ${n.name || n.selector}`,
          selector: v.nodes.slice(0, 15).map(x => x.selector).filter(Boolean).join('\n'), html: n.html,
          problem: `${v.help}. Same problem on ${v.nodes.length} elements. Example: ${clean(n.summary)}`,
          fix: `${v.description}. Usually fixed once in the shared component/template.`, ...base, screenshot: await shot(n.selector) });
      }
    }
    for (const v of res.incomplete) {
      needsReview.push({ element: v.nodes.length > 1 ? `${v.nodes.length} elements — e.g. ${v.nodes[0].name || v.nodes[0].selector}` : (v.nodes[0]?.name || v.help),
        problem: `${v.help} — the tool could not decide automatically; check by eye.`, wcag: wcagFromTags(v.tags).wcag });
    }
    passedHighlights.push(...res.passes.slice(0, 10));
  } catch (e) {
    axeAvailable = false;
    needsReview.push({ element: 'Whole page', problem: `Automated axe scan failed (${e.message.split('\n')[0]}). Only keyboard and structure checks ran.`, wcag: '' });
  }

  // ---------- B. Keyboard pass ----------
  let keyboardStops = null;
  if (!QUICK) {
    await page.evaluate(() => { document.activeElement && document.activeElement.blur(); window.scrollTo(0, 0); });
    const stops = [];
    let sameCount = 0;
    for (let i = 0; i < MAX_TABS; i++) {
      await page.keyboard.press('Tab');
      await page.waitForTimeout(60);
      const s = await page.evaluate((idx) => {
        let el = document.activeElement;
        while (el && el.shadowRoot && el.shadowRoot.activeElement) el = el.shadowRoot.activeElement;
        if (!el || el === document.body || el === document.documentElement) return null;
        if (el.tagName === 'IFRAME') return { key: 'iframe:' + (el.src || idx), iframe: true, desc: window.__a11yDescribe(el) };
        if (!el.hasAttribute('data-a11y-k')) el.setAttribute('data-a11y-k', 'k' + idx);
        const props = ['outlineStyle', 'outlineWidth', 'outlineColor', 'boxShadow', 'borderTopColor', 'borderBottomColor', 'borderBottomWidth', 'backgroundColor', 'color', 'textDecorationLine'];
        const read = () => { const cs = getComputedStyle(el); return props.map(p => cs[p]).join('|'); };
        const focused = read();
        const cs = getComputedStyle(el);
        const outlineVisible = cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0;
        el.blur(); const unfocused = read(); el.focus({ preventScroll: true });
        const r = el.getBoundingClientRect();
        const hidden = r.width < 1 || r.height < 1 || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0 || r.right < 0 || r.bottom < 0 || r.left > innerWidth;
        return { key: el.getAttribute('data-a11y-k'), selector: `[data-a11y-k="${el.getAttribute('data-a11y-k')}"]`, desc: window.__a11yDescribe(el),
          name: window.__a11yName(el), axe: /\b(button-name|link-name|label|input-button-name|aria-command-name|select-name|image-alt|input-image-alt|aria-input-field-name|frame-title)\b/.test(el.getAttribute('data-a11y-axe') || ''), noIndicator: !outlineVisible && focused === unfocused,
          hidden, top: r.top + scrollY, role: el.getAttribute('role') || el.tagName.toLowerCase(), html: el.outerHTML.slice(0, 200) };
      }, i);
      if (!s) { if (stops.length) break; else continue; }
      if (stops.length && s.key === stops[0].key) break; // looped back to the start
      if (stops.length && s.key === stops[stops.length - 1].key) { if (++sameCount >= 3) { s.trap = true; stops.push(s); break; } continue; }
      sameCount = 0;
      stops.push(s);
    }
    keyboardStops = stops.length;
    const add = async (o) => issues.push({ no: issues.length + 1, source: 'keyboard', ...o });

    const trap = stops.find(s => s.trap);
    if (trap) await add({ element: trap.desc, selector: trap.selector, html: trap.html, impact: 'critical', wcag: '2.1.2', wcagName: SC['2.1.2'], level: 'A',
      problem: 'Keyboard focus gets stuck on this element. Pressing Tab does not move on, so keyboard and screen-reader users cannot get past it.',
      fix: 'Make sure Tab and Shift+Tab can always leave the component. For modals, trap focus only while open and provide Escape to close.', screenshot: await shot(trap.selector) });

    const noInd = stops.filter(s => !s.iframe && s.noIndicator && !s.hidden);
    if (noInd.length) {
      const first = noInd[0];
      await add({ element: noInd.length === 1 ? first.desc : `${noInd.length} focusable elements — e.g. ${first.desc}`, selector: noInd.slice(0, 15).map(s => s.desc).join('\n'),
        html: first.html, impact: 'serious', wcag: '2.4.7', wcagName: SC['2.4.7'], level: 'AA',
        problem: 'Nothing visibly changes when this element gets keyboard focus, so sighted keyboard users cannot see where they are on the page.',
        fix: 'Add a clear focus style, e.g. :focus-visible { outline: 3px solid #1a73e8; outline-offset: 2px; }. Never use outline: none without a replacement.',
        screenshot: await shot(first.selector) });
    }
    const hidden = stops.filter(s => !s.iframe && s.hidden);
    if (hidden.length) await add({ element: hidden.length === 1 ? hidden[0].desc : `${hidden.length} hidden elements — e.g. ${hidden[0].desc}`,
      selector: hidden.map(s => s.desc).join('\n'), html: hidden[0].html, impact: 'serious', wcag: '2.4.7, 2.4.11', wcagName: `${SC['2.4.7']}; ${SC['2.4.11']}`, level: 'AA',
      problem: 'Keyboard focus lands on something that is invisible or off-screen. Users press Tab and focus seems to disappear.',
      fix: 'Remove hidden elements from the tab order (display:none, the inert attribute, or tabindex="-1"), or make them visible when focused.', screenshot: null });

    const unnamed = stops.filter(s => !s.iframe && !s.name && !s.axe);
    for (const s of unnamed.slice(0, 5)) await add({ element: s.desc, selector: s.selector, html: s.html, impact: 'serious', wcag: '4.1.2', wcagName: SC['4.1.2'], level: 'A',
      problem: `A screen reader (JAWS/NVDA) would announce this only as "${s.role}" with no name, so the user doesn't know what it does.`,
      fix: 'Give it visible text, or an aria-label / aria-labelledby that describes its purpose.', screenshot: await shot(s.selector) });

    if (stops.length >= 8 && !/skip|main content|jump to/i.test(stops.slice(0, 3).map(s => s.name).join(' ')))
      await add({ element: 'Start of page', impact: 'moderate', wcag: '2.4.1', wcagName: SC['2.4.1'], level: 'A', html: '',
        problem: `There is no "Skip to main content" link among the first Tab stops. Keyboard users must Tab through the header and menu (${stops.length}+ stops) on every page.`,
        fix: 'Add <a class="skip-link" href="#main">Skip to main content</a> as the first element, visible on focus, and give the main region id="main".', screenshot: null });

    let jumps = 0;
    for (let i = 1; i < stops.length; i++) if (stops[i].top < stops[i - 1].top - 300) jumps++;
    if (jumps >= 3) needsReview.push({ element: 'Tab order', problem: `Focus jumps back up the page ${jumps} times during the Tab pass. Check that the order makes sense.`, wcag: '2.4.3' });
    if (stops.some(s => s.iframe)) needsReview.push({ element: 'Embedded frame(s)', problem: 'Focus moves into an iframe. Content inside cross-origin frames was not tested; check it separately.', wcag: '' });

    // Mouse-only controls (clickable but not reachable by keyboard)
    const mouseOnly = await page.evaluate(() => {
      const out = [];
      const cand = document.querySelectorAll('[onclick],[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=switch]');
      for (const el of cand) {
        if (['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'SUMMARY'].includes(el.tagName) || el.tabIndex >= 0 || el.closest('a,button')) continue;
        const r = el.getBoundingClientRect(); if (r.width < 1 || r.height < 1) continue;
        el.setAttribute('data-a11y-m', String(out.length));
        out.push({ selector: `[data-a11y-m="${out.length}"]`, desc: window.__a11yDescribe(el), html: el.outerHTML.slice(0, 200) });
        if (out.length >= 10) break;
      }
      return out;
    });
    if (mouseOnly.length) await add({ element: mouseOnly.length === 1 ? mouseOnly[0].desc : `${mouseOnly.length} controls — e.g. ${mouseOnly[0].desc}`,
      selector: mouseOnly.map(m => m.desc).join('\n'), html: mouseOnly[0].html, impact: 'critical', wcag: '2.1.1', wcagName: SC['2.1.1'], level: 'A',
      problem: 'This control works with a mouse click but cannot be reached with the Tab key, so keyboard and screen-reader users cannot use it.',
      fix: 'Use a real <button> or <a href>. If that is not possible, add tabindex="0" and handle Enter/Space key presses.', screenshot: await shot(mouseOnly[0].selector) });
  }

  // ---------- C. Structure checks axe doesn't cover ----------
  const struct = await page.evaluate(() => {
    const vague = /^(click here|here|read more|more|learn more|link|details|go|this)$/i;
    const links = [...document.querySelectorAll('a[href]')].filter(a => vague.test((a.innerText || '').trim()) && !a.getAttribute('aria-label') && !a.getAttribute('aria-labelledby'));
    links.forEach((a, i) => a.setAttribute('data-a11y-v', String(i)));
    const ph = [...document.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]),textarea')]
      .filter(i => i.getAttribute('placeholder') && !(i.labels && i.labels.length) && !i.getAttribute('aria-label') && !i.getAttribute('aria-labelledby') && !/\blabel\b/.test(i.getAttribute('data-a11y-axe') || ''));
    ph.forEach((el, i) => el.setAttribute('data-a11y-p', String(i)));
    const h = [...document.querySelectorAll('h1')].length;
    return {
      vague: links.slice(0, 10).map((a, i) => ({ selector: `[data-a11y-v="${i}"]`, desc: window.__a11yDescribe(a), html: a.outerHTML.slice(0, 200) })),
      placeholder: ph.slice(0, 10).map((el, i) => ({ selector: `[data-a11y-p="${i}"]`, desc: window.__a11yDescribe(el), html: el.outerHTML.slice(0, 200) })),
      h1: h, lang: document.documentElement.lang, title: document.title,
      main: !!document.querySelector('main,[role=main]'), imgNoAlt: document.querySelectorAll('img:not([alt])').length,
    };
  });
  if (struct.vague.length) issues.push({ no: issues.length + 1, source: 'structure', element: struct.vague.length === 1 ? struct.vague[0].desc : `${struct.vague.length} links — e.g. ${struct.vague[0].desc}`,
    selector: struct.vague.map(v => v.desc).join('\n'), html: struct.vague[0].html, impact: 'moderate', wcag: '2.4.4', wcagName: SC['2.4.4'], level: 'A',
    problem: 'Link text like "Read more" or "Click here" makes no sense out of context. Screen-reader users often browse a list of links, and these all sound the same.',
    fix: 'Use descriptive text ("Read more about home loans") or add an aria-label containing the purpose.', screenshot: await shot(struct.vague[0].selector) });
  for (const p of struct.placeholder.slice(0, 3)) issues.push({ no: issues.length + 1, source: 'structure', element: p.desc, selector: p.selector, html: p.html,
    impact: 'moderate', wcag: '3.3.2', wcagName: SC['3.3.2'], level: 'A',
    problem: 'This field is labelled only by placeholder text, which disappears as soon as the user types and is often read inconsistently by screen readers.',
    fix: 'Add a visible <label for="..."> (the placeholder can stay as a hint).', screenshot: await shot(p.selector) });
  if (!axeAvailable) {
    const addS = (o) => issues.push({ no: issues.length + 1, source: 'structure', html: '', screenshot: null, ...o });
    if (!struct.lang) addS({ element: 'Whole page', impact: 'serious', wcag: '3.1.1', wcagName: SC['3.1.1'], level: 'A', problem: 'The page has no lang attribute, so screen readers may use the wrong pronunciation.', fix: 'Add <html lang="en">.' });
    if (!struct.title.trim()) addS({ element: 'Whole page', impact: 'serious', wcag: '2.4.2', wcagName: SC['2.4.2'], level: 'A', problem: 'The page has no title.', fix: 'Add a descriptive <title>.' });
    if (!struct.h1) addS({ element: 'Whole page', impact: 'moderate', wcag: '1.3.1', wcagName: SC['1.3.1'], level: 'Best practice', problem: 'The page has no h1 heading.', fix: 'Add one h1 describing the page.' });
    if (!struct.main) addS({ element: 'Whole page', impact: 'moderate', wcag: '1.3.1', wcagName: SC['1.3.1'], level: 'Best practice', problem: 'No main landmark.', fix: 'Wrap the main content in <main>.' });
    if (struct.imgNoAlt) addS({ element: `${struct.imgNoAlt} images`, impact: 'critical', wcag: '1.1.1', wcagName: SC['1.1.1'], level: 'A', problem: 'Images without alt attribute.', fix: 'Add meaningful alt text, or alt="" for decorative images.' });
  }
  needsReview.push({ element: 'Images and media', problem: 'Check that alt text is meaningful (not just present) and that videos have accurate captions.', wcag: '1.1.1, 1.2.2' });

  // ---------- Clean up, save ----------
  await page.evaluate(() => {
    document.querySelectorAll('[data-a11y-k],[data-a11y-axe],[data-a11y-m],[data-a11y-v],[data-a11y-p]').forEach(el =>
      ['data-a11y-k', 'data-a11y-axe', 'data-a11y-m', 'data-a11y-v', 'data-a11y-p'].forEach(a => el.removeAttribute(a)));
    document.activeElement && document.activeElement.blur(); window.scrollTo(0, 0);
  }).catch(() => {});
  issues.forEach((i, idx) => { i.no = idx + 1; if (/data-a11y-/.test(i.selector || '')) i.selector = ''; });

  const record = { id: pageId, url, title, testedAt: new Date().toISOString(), axeAvailable, keyboardStops, pageScreenshot, issues, needsReview, passedHighlights };
  if (existing >= 0) findings.pages[existing] = record; else findings.pages.push(record);
  fs.writeFileSync(findingsFile, JSON.stringify(findings, null, 2));

  const c = imp => issues.filter(i => i.impact === imp).length;
  console.log(`RESULT ${pageId} | ${title} | ${url}`);
  console.log(`Critical ${c('critical')} · Serious ${c('serious')} · Moderate ${c('moderate')} · Minor ${c('minor')} · Needs review ${needsReview.length}` +
    (keyboardStops != null ? ` · Keyboard stops ${keyboardStops}` : '') + (axeAvailable ? '' : ' · axe FAILED'));
  issues.slice(0, 8).forEach(i => console.log(`  ${i.no}. [${i.impact}] ${i.element} — ${i.wcag} — ${i.problem.slice(0, 140)}`));
  if (issues.length > 8) console.log(`  … and ${issues.length - 8} more (see findings.json)`);
  await browser.close(); // disconnects only; the user's browser window stays open
})().catch(e => { console.error('SCAN_ERROR:', e.message); process.exit(1); });
